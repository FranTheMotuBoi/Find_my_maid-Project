<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();


if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$user_name = $_SESSION['user_name'];


$sql_user = "SELECT * FROM user_form WHERE name = '$user_name'";
$result_user = mysqli_query($conn, $sql_user);

if (mysqli_num_rows($result_user) == 1) {
    $user_profile = mysqli_fetch_assoc($result_user);
} else {

    echo "Error fetching user data.";
    exit();
}


$sql_jobs = "SELECT * FROM post_maid";
$result_jobs = mysqli_query($conn, $sql_jobs);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Page</title>
    <link rel="stylesheet" href="css/style.css">
    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #333;
            overflow: hidden;
            padding: 10px 20px;
        }
        .navbar a {
            float: right;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
            margin-top: 60px; 
        }
        h1 {
            text-align: center;
        }
        .profile-img {
            max-width: 200px;
            margin-bottom: 20px;
        }
        .job-listing {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            position: relative; 
        }
        .job-listing p {
            margin: 5px 0;
        }
        .hire-button {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 8px 16px;
            background-color: crimson;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .hire-button:hover {
            background-color: darkred;
        }
        .search-form {
        float: right;
        margin-right: 20px;
        }

        .search-input {
        width: 250px; 
        padding: 8px;
        border-radius: 5px;
        border: 1px solid #ccc;
        font-size: 16px; 
        }

        .search-button {
        padding: 10px 20px; 
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px; 
        }

        .search-button:hover {
        background-color: #0056b3;
        }
        .profile-img {
    max-width: 150px; 
    height: auto; 
    margin-bottom: 20px;
    border-radius: 50%; 
    border: 2px solid #ccc; 
    display: block; 
    margin-left: auto; 
    margin-right: auto; 
}
.profile-info {
    text-align: center;
}


    </style>
</head>
<body>
    <div class="navbar">
        <a href="update_profile.php">Update Profile</a>
        <a href="hire_maid.php">Hire a Maid</a>
        <a href="your_maids.php">Your Maids</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h1>Welcome, <?php echo $user_profile['name']; ?>!</h1>

        <img src="uploaded_img/<?php echo $user_profile['image']; ?>" alt="Profile Picture" class="profile-img">

        <div class="profile-info">
    <h3>Your Profile Information</h3>
    <p><strong>Name:</strong> <?php echo $user_profile['name']; ?></p>
    <p><strong>Email:</strong> <?php echo $user_profile['email']; ?></p>
    <p><strong>Phone Number:</strong> <?php echo $user_profile['phone_number']; ?></p>
    <p><strong>Preferred Jobs:</strong> <?php echo $user_profile['jobs']; ?></p>
    <p><strong>Address:</strong> <?php echo $user_profile['address']; ?></p>
</div>
 <br><br>
       
        <div class="search-form">
            <form action="search_maid.php" method="get">
                <input type="text" name="search" class="search-input" placeholder="Search by location/salary...">
                <button type="submit" class="search-button">Search</button>
            </form>
        </div> <br>
        <h2><br>Job Posted by Candidates: <br></h2><br>
        <?php
        if (mysqli_num_rows($result_jobs) > 0) {
            while ($row = mysqli_fetch_assoc($result_jobs)) {
                
        ?>
            <div class="job-listing">
                <p><strong>Candidate Name:</strong> <?php echo $row['candidate_name']; ?></p>
                <p><strong>Preferred Location:</strong> <?php echo $row['preferred_location']; ?></p>
                <p><strong>Preferred Jobs:</strong> <?php echo $row['preferred_jobs']; ?></p>
                <p><strong>Previous Job Location:</strong> <?php echo $row['previous_job_location']; ?></p>
                <p><strong>Experience:</strong> <?php echo $row['experience']; ?></p>
                <p><strong>Expected Salary:</strong> <?php echo $row['expected_salary']; ?></p>
            
                <button class="hire-button">Hire</button>
                <form action="hire_candidate.php" method="post">
                    <input type="hidden" name="candidate_name" value="<?php echo $row['candidate_name']; ?>">
                    <input type="hidden" name="preferred_location" value="<?php echo $row['preferred_location']; ?>">
                    <input type="hidden" name="preferred_jobs" value="<?php echo $row['preferred_jobs']; ?>">
                    <input type="hidden" name="previous_job_location" value="<?php echo $row['previous_job_location']; ?>">
                    <input type="hidden" name="experience" value="<?php echo $row['experience']; ?>">
                    <input type="hidden" name="expected_salary" value="<?php echo $row['expected_salary']; ?>">
                    <button type="submit" name="hire_candidate" class="hire-button">Hire</button>
                </form>


                    
                    
            </div>
        <?php
            }
        } else {
            echo "No job postings available.";
        }
        ?>
    </div>
</body>
</html>
