<?php

session_start();


if (!isset($_SESSION['candidate_name'])) {
    header("Location: login.php");
    exit();
}


$candidate_name = $_SESSION['candidate_name'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Job</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .job-listing {
            border: 1px solid #ccc;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .job-listing p {
            margin: 5px 0;
        }
        .apply-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .apply-btn:hover {
            background-color: #0056b3;
        }
        .navbar {
            text-align: right;
            margin-bottom: 20px;
        }
        .navbar a {
            color: #007bff;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 5px;
            margin-left: 10px;
        }
        .navbar a:hover {
            background-color: #007bff;
            color: white;
        }
        .profile-btn { /* Added */
            background-color: #28a745;
            color: white;
        }
        .profile-btn:hover { /* Added */
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="update_candidate.php">Update Profile</a>
        <a href="post_maid.php">Ask for a Job</a>
        <a href="logout.php">Logout</a>
        <a href="candidate_page.php" class="profile-btn">Profile</a> <!-- Added -->
    </div>

    <div class="container">
        <h1>Apply for Job</h1>
        <?php

        $sql_job_listings = "SELECT * FROM hire_maid";
        $result_job_listings = mysqli_query($conn, $sql_job_listings);

 
        if (!$result_job_listings) {
            echo "Error fetching job listings.";
            exit();
        }


        if (mysqli_num_rows($result_job_listings) > 0) {
            while ($row = mysqli_fetch_assoc($result_job_listings)) {
                echo "<div class='job-listing'>";
                echo "<p><strong>Name:</strong> " . $row['name'] . "</p>";
                echo "<p><strong>Job Location:</strong> " . $row['job_location'] . "</p>";
                echo "<p><strong>Working Hours:</strong> " . $row['working_hours'] . "</p>";
                echo "<p><strong>Starting Date:</strong> " . $row['starting_date'] . "</p>";
                echo "<p><strong>Jobs:</strong> " . $row['jobs'] . "</p>";
                echo "<p><strong>Salary:</strong> " . $row['salary'] . "</p>";
                echo "<p><strong>Extra Benefits:</strong> " . $row['extra_benefits'] . "</p>";
                echo "<form action='' method='post'>";
                echo "<input type='hidden' name='hired_by' value='" . $row['name'] . "'>";
                echo "<input type='hidden' name='job_location' value='" . $row['job_location'] . "'>";
                echo "<input type='hidden' name='working_hours' value='" . $row['working_hours'] . "'>";
                echo "<input type='hidden' name='starting_date' value='" . $row['starting_date'] . "'>";
                echo "<input type='hidden' name='jobs' value='" . $row['jobs'] . "'>";
                echo "<input type='hidden' name='salary' value='" . $row['salary'] . "'>";
                echo "<input type='hidden' name='extra_benefits' value='" . $row['extra_benefits'] . "'>";
                echo "<button type='submit' class='apply-btn'>Apply</button>";
                echo "</form>";
                echo "</div>";
            }
        } else {
            echo "No job listings available.";
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Extract form data
            $hired_by = isset($_POST['hired_by']) ? $_POST['hired_by'] : '';
            $job_location = isset($_POST['job_location']) ? $_POST['job_location'] : '';
            $working_hours = isset($_POST['working_hours']) ? $_POST['working_hours'] : '';
            $starting_date = isset($_POST['starting_date']) ? $_POST['starting_date'] : '';
            $jobs = isset($_POST['jobs']) ? $_POST['jobs'] : '';
            $salary = isset($_POST['salary']) ? $_POST['salary'] : '';
            $extra_benefits = isset($_POST['extra_benefits']) ? $_POST['extra_benefits'] : '';

       
            $sql_insert = "INSERT INTO candidate_history (candidate_name, hired_by, job_location, working_hours, starting_date, jobs, salary, extra_benefits) 
                            VALUES ('$candidate_name', '$hired_by', '$job_location', '$working_hours', '$starting_date', '$jobs', '$salary', '$extra_benefits')";
            
            if (mysqli_query($conn, $sql_insert)) {
                echo "<p>Application submitted successfully!</p>";


                exit();
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        }

        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
