<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['preferred_location']) && isset($_POST['preferred_jobs']) && isset($_POST['experience']) && isset($_POST['previous_job_location']) && isset($_POST['expected_salary'])) {
    $candidate_name = $_SESSION['candidate_name']; // Get candidate's name from session
    $preferred_location = mysqli_real_escape_string($conn, $_POST['preferred_location']);
    $preferred_jobs = mysqli_real_escape_string($conn, $_POST['preferred_jobs']);
    $experience = mysqli_real_escape_string($conn, $_POST['experience']);
    $previous_job_location = mysqli_real_escape_string($conn, $_POST['previous_job_location']);
    $expected_salary = mysqli_real_escape_string($conn, $_POST['expected_salary']);

 
    $sql = "INSERT INTO post_maid (candidate_name, preferred_location, preferred_jobs, experience, previous_job_location, expected_salary)
            VALUES ('$candidate_name', '$preferred_location', '$preferred_jobs', '$experience', '$previous_job_location', '$expected_salary')";

    if (mysqli_query($conn, $sql)) {

        $_SESSION['post_success'] = true;
        header("Location: candidate_page.php");
        exit();
    } else {

        $_SESSION['post_error'] = "Error posting the job. Please try again.";
        header("Location: post_maid.php");
        exit();
    }
} else {

    $_SESSION['post_error'] = "Invalid form submission. Please fill in all fields.";
    header("Location: post_maid.php");
    exit();
}

mysqli_close($conn);
?>
