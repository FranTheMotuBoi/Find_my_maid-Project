<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();


if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$user_name = $_SESSION['user_name'];


$sql_maids = "SELECT * FROM hired_maids WHERE name = '$user_name'";
$result_maids = mysqli_query($conn, $sql_maids);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Maids</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            text-decoration: underline;
        }

        .review-button {
            background-color: crimson;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 6px 12px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Hired Maids</h1>
        <table>
            <tr>
                <th>Maid Name</th>
                <th>Preferred Location</th>
                <th>Preferred Jobs</th>
                <th>Previous Job Location</th>
                <th>Experience</th>
                <th>Expected Salary</th>
                <th>Review and Rating</th>
            </tr>
            <?php
            if (mysqli_num_rows($result_maids) > 0) {
                while ($row = mysqli_fetch_assoc($result_maids)) {
                    echo "<tr>";
                    echo "<td>" . $row['maid_name'] . "</td>";
                    echo "<td>" . $row['preferred_location'] . "</td>";
                    echo "<td>" . $row['preferred_jobs'] . "</td>";
                    echo "<td>" . $row['previous_job_location'] . "</td>";
                    echo "<td>" . $row['experience'] . "</td>";
                    echo "<td>" . $row['expected_salary'] . "</td>";
                    echo "<td><a href='review_rating.php'><button class='review-button'>Review and Rating</button></a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No maids hired yet.</td></tr>";
            }
            ?>
        </table>
        <a href="user_page.php">Back to Profile</a>
    </div>
</body>
</html>

