<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (!isset($_GET['job_id'])) {
    echo "Error: Job ID not provided.";
    exit();
}

$job_id = $_GET['job_id']; 


$sql_job_details = "SELECT * FROM hire_maid WHERE job_id = $job_id";
$result_job_details = mysqli_query($conn, $sql_job_details);


if (!$result_job_details || mysqli_num_rows($result_job_details) == 0) {
    echo "Error: Job not found.";
    exit();
}


$job_details = mysqli_fetch_assoc($result_job_details);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Job Details</title>
 
    <style>
      
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .job-details {
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
        }
        .job-details p {
            margin: 5px 0;
        }
        .apply-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .apply-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Job Details</h1>
        <div class="job-details">
            <p><strong>Name:</strong> <?php echo $job_details['name']; ?></p>
            <p><strong>Job Location:</strong> <?php echo $job_details['job_location']; ?></p>
            <p><strong>Working Hours:</strong> <?php echo $job_details['working_hours']; ?></p>
            <p><strong>Starting Date:</strong> <?php echo $job_details['starting_date']; ?></p>
            <p><strong>Jobs:</strong> <?php echo $job_details['jobs']; ?></p>
            <p><strong>Salary:</strong> <?php echo $job_details['salary']; ?></p>
            <p><strong>Extra Benefits:</strong> <?php echo $job_details['extra_benefits']; ?></p>
            <form action="apply.php" method="post">
                <input type="hidden" name="job_id" value="<?php echo $job_id; ?>">
                <button type="submit" class="apply-btn">Apply</button>
            </form>
        </div>
    </div>
</body>
</html>

<?php

mysqli_close($conn);
?>
