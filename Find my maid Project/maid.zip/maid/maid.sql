-- Create the findmymaid database
CREATE DATABASE IF NOT EXISTS findmaid;

-- Use the findmymaid database
USE findmaid;

-- Create the candidate_history table
CREATE TABLE IF NOT EXISTS candidate_history (
    candidate_id INT PRIMARY KEY AUTO_INCREMENT,
    candidate_name VARCHAR(100),
    candidate_age INT,
    candidate_experience INT,
    candidate_skills VARCHAR(255),
    candidate_contact VARCHAR(20),
    candidate_address VARCHAR(255),
    candidate_notes TEXT
);

-- Create the hire_maid table
CREATE TABLE IF NOT EXISTS hire_maid (
    hire_id INT PRIMARY KEY AUTO_INCREMENT,
    maid_id INT,
    employer_id INT,
    hire_date DATE,
    salary DECIMAL(10, 2),
    contract_duration INT,
    FOREIGN KEY (maid_id) REFERENCES candidate_history(candidate_id),
    FOREIGN KEY (employer_id) REFERENCES user_form(user_id)
);

-- Create the post_maid table
CREATE TABLE IF NOT EXISTS post_maid (
    post_id INT PRIMARY KEY AUTO_INCREMENT,
    employer_id INT,
    post_date DATE,
    job_description TEXT,
    FOREIGN KEY (employer_id) REFERENCES user_form(user_id)
);

-- Create the user_form table
CREATE TABLE IF NOT EXISTS user_form (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    email VARCHAR(100),
    password VARCHAR(100),
    address VARCHAR(255),
    contact_number VARCHAR(20)
);
