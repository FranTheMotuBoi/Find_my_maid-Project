<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";


if (isset($_POST['job_location'], $_POST['working_hours'], $_POST['starting_date'],$_POST['jobs'], $_POST['salary'], $_POST['extra_benefits'])) {

    $conn = mysqli_connect($servername, $username, $password, $dbname);


    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if (isset($_SESSION['user_name'])) {
        $user_name = $_SESSION['user_name'];

        $job_location = mysqli_real_escape_string($conn, $_POST['job_location']);
        $working_hours = mysqli_real_escape_string($conn, $_POST['working_hours']);
        $starting_date = mysqli_real_escape_string($conn, $_POST['starting_date']);
        $jobs = mysqli_real_escape_string($conn, $_POST['jobs']);
        $salary = mysqli_real_escape_string($conn, $_POST['salary']);
        $extra_benefits = mysqli_real_escape_string($conn, $_POST['extra_benefits']);

    
        $insert_query = "INSERT INTO hire_maid (name, job_location, working_hours, starting_date,jobs, salary, extra_benefits) 
                         VALUES ('$user_name', '$job_location', '$working_hours','$starting_date', '$jobs', '$salary', '$extra_benefits')";

        if (mysqli_query($conn, $insert_query)) {

            header("Location: user_page.php");
            exit();
        } else {
            echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "User name not found in session.";
    }

    mysqli_close($conn);
} else {

    header("Location: hire_maid.php");
    exit();
}
?>
