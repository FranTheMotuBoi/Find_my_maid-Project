<?php
session_start();

if (!isset($_SESSION['candidate_name'])) {
    header("Location: login.php");
    exit();
}


$candidate_name = $_SESSION['candidate_name'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a Job</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .form-group input[readonly] {
            background-color: #f9f9f9; /* Read-only field background color */
            cursor: not-allowed;
        }
        .form-group textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
            resize: vertical;
        }
        .form-btn {
            background-color: #dc143c; /* Crimson color */
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
            text-decoration: none;
            text-align: center;
        }
        .form-btn:hover {
            background-color: #a10f2e; /* Darken on hover */
        }
        .error-msg {
            color: red;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Ask for a job</h2>

        <form action="process_post_maid.php" method="POST">
            <div class="form-group">
                <label for="candidate_name">Candidate Name:</label>
                <input type="text" id="candidate_name" name="candidate_name" value="<?php echo $candidate_name; ?>" readonly>
            </div>
            <div class="form-group">
                <label for="preferred_location">Preferred Location:</label>
                <input type="text" id="preferred_location" name="preferred_location" placeholder="Enter preferred location" required>
            </div>
            <div class="form-group">
                <label for="preferred_jobs">Preferred Jobs:</label>
                <input type="text" id="preferred_jobs" name="preferred_jobs" placeholder="Enter preferred jobs" required>
            </div>
            <div class="form-group">
                <label for="experience">Experience:</label>
                <input type="text" id="experience" name="experience" placeholder="Enter experience" required>
            </div>
            <div class="form-group">
                <label for="previous_job_location">Previous Job Location:</label>
                <input type="text" id="previous_job_location" name="previous_job_location" placeholder="Enter previous job location" required>
            </div>
            <div class="form-group">
                <label for="expected_salary">Expected Salary:</label>
                <input type="text" id="expected_salary" name="expected_salary" placeholder="Enter expected salary" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Post" class="form-btn">
            </div>
        </form>
    </div>
</body>
</html>
