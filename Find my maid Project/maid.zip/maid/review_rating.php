<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$user_name = $_SESSION['user_name'];

// Fetch maids hired by the user
$sql_maids = "SELECT * FROM hired_maids WHERE name = '$user_name'";
$result_maids = mysqli_query($conn, $sql_maids);

$maid_names = [];
while ($row = mysqli_fetch_assoc($result_maids)) {
    $maid_names[] = $row['maid_name'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle form submission
    $maid_name = $_POST['maid_name'];
    $rating = $_POST['rating'];
    $response = $_POST['response'];

    // Insert data into feedback table
    $sql_insert_feedback = "INSERT INTO feedback (maid_name, rating, response) VALUES ('$maid_name', '$rating', '$response')";
    if (mysqli_query($conn, $sql_insert_feedback)) {
        echo "Review Submitted!";
        // Redirect to user_page.php after submission
        header("refresh:2;url=user_page.php");
        exit();
    } else {
        echo "Error: " . $sql_insert_feedback . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review and Rating</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .rating {
            display: inline-block;
        }

        .rating input[type="radio"] {
            display: none;
        }

        .rating label {
            color: #ddd;
            font-size: 30px;
            float: right;
        }

        .rating label:before {
            content: "\2605";
            margin-right: 5px;
        }

        .rating input[type="radio"]:checked ~ label {
            color: #f90;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Review and Rating</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="maid_name">Maid Name:</label>
            <select name="maid_name" id="maid_name" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box;">
    <?php foreach ($maid_names as $maid) : ?>
        <option value="<?php echo $maid; ?>"><?php echo $maid; ?></option>
    <?php endforeach; ?>
</select> <br>
<label for="rating">Rating:</label>
            <div class="rating">
                <input type="radio" id="star5" name="rating" value="5"><label for="star5"></label>
                <input type="radio" id="star4" name="rating" value="4"><label for="star4"></label>
                <input type="radio" id="star3" name="rating" value="3"><label for="star3"></label>
                <input type="radio" id="star2" name="rating" value="2"><label for="star2"></label>
                <input type="radio" id="star1" name="rating" value="1"><label for="star1"></label>
            </div>
            <label for="response">Response:</label>
            <textarea name="response" id="response" rows="4" cols="50" required></textarea>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
