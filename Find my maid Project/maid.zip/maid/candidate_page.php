<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


session_start();


if (!isset($_SESSION['candidate_name'])) {
    header("Location: login.php");
    exit();
}

$candidate_id = $_SESSION['candidate_id']; // Get candidate ID from session


$sql_profile = "SELECT * FROM user_form WHERE id = '$candidate_id' AND user_type = 'candidate'";
$result_profile = mysqli_query($conn, $sql_profile);

if (mysqli_num_rows($result_profile) == 1) {
    $candidate_profile = mysqli_fetch_assoc($result_profile);
} else {

    echo "Error fetching candidate data.";
    exit();
}

$sql_jobs = "SELECT * FROM hire_maid";
$result_jobs = mysqli_query($conn, $sql_jobs);


if (!$result_jobs) {
    echo "Error: " . mysqli_error($conn);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Profile</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .profile-img {
            max-width: 200px;
            margin-bottom: 20px;
        }
        .job-listing {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            position: relative;
        }
        .job-listing p {
            margin: 5px 0;
        }
        .apply-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: crimson;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .apply-btn:hover {
            background-color: darkred;
        }
        .navbar {
            text-align: right;
            margin-bottom: 20px;
        }
        .navbar a {
            color: #007bff;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 5px;
            margin-left: 10px;
        }
        .navbar a:hover {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="update_candidate.php">Update Profile</a>
        <a href="post_maid.php">Ask for a Job</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <h1>Welcome, <?php echo $candidate_profile['name']; ?>!</h1>
        <img src="uploaded_img/<?php echo $candidate_profile['image']; ?>" alt="Profile Picture" class="profile-img">
        <div>
            <h3>Your Candidate Profile Information</h3>
            <p><strong>Name:</strong> <?php echo $candidate_profile['name']; ?></p>
            <p><strong>Email:</strong> <?php echo $candidate_profile['email']; ?></p>
            <p><strong>Phone Number:</strong> <?php echo $candidate_profile['phone_number']; ?></p>
            <p><strong>Preferred Jobs:</strong> <?php echo $candidate_profile['jobs']; ?></p>
            <p><strong>Address:</strong> <?php echo $candidate_profile['address']; ?></p>
        </div>
        <h2>Job posted by Users</h2>
        <?php
        if (mysqli_num_rows($result_jobs) > 0) {
            while ($row = mysqli_fetch_assoc($result_jobs)) {
        ?>
            <div class="job-listing">
                <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
                <p><strong>Job Location:</strong> <?php echo $row['job_location']; ?></p>
                <p><strong>Working Hours:</strong> <?php echo $row['working_hours']; ?></p>
                <p><strong>Starting Date:</strong> <?php echo $row['starting_date']; ?></p>
                <p><strong>Jobs:</strong> <?php echo $row['jobs']; ?></p>
                <p><strong>Salary:</strong> <?php echo $row['salary']; ?></p>
                <p><strong>Extra Benefits:</strong> <?php echo $row['extra_benefits']; ?></p>
                <a href="apply.php" class="apply-btn">Apply</a> <!-- Updated -->
            </div>
        <?php
            }
        } else {
            echo "No job listings available.";
        }
        ?>
    </div>
</body>
</html>
