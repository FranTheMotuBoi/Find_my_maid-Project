<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$user_name = $_SESSION['user_name'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hire a Maid</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        h1, h2 {
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Welcome, <?php echo $user_name; ?>!</h1>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <h2>Hire a Maid</h2>
        <form action="process_hire_maid.php" method="post">
            <label for="job_location">Job Location:</label>
            <input type="text" id="job_location" name="job_location" required><br><br>

            <label for="working_hours">Working Hours:</label>
            <input type="text" id="working_hours" name="working_hours" required><br><br>
            
            <label for="starting_date">Starting Date:</label>
            <input type="date" id="starting_date" name="starting_date" required><br><br>

            <label for="jobs">Jobs:</label>
            <input type="text" id="jobs" name="jobs" required><br><br>

            <label for="salary">Salary:</label>
            <input type="text" id="salary" name="salary" required><br><br>

            <label for="extra_benefits">Extra Benefits:</label>
            <input type="text" id="extra_benefits" name="extra_benefits"><br><br>

            <input type="submit" name="hire_maid" value="Hire a Maid">
        </form>
    </div>
</body>
</html>
