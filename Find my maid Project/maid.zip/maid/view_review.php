<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Reviews</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .review {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
        }
        .review p {
            margin: 5px 0;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
   
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "findmymaid";

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        if (isset($_POST['view_review'])) {
            $maid_name = $_POST['candidate_name'];

            $sql_reviews = "SELECT * FROM feedback WHERE maid_name = '$maid_name'";
            $result_reviews = mysqli_query($conn, $sql_reviews);

            if (mysqli_num_rows($result_reviews) > 0) {
                echo "<h1>Reviews for $maid_name</h1>"; 
                while ($row_review = mysqli_fetch_assoc($result_reviews)) {
                    
                    echo "<div class='review'>";
                    echo "<p><strong>Rating:</strong> " . $row_review['rating'] . "</p>";
                    echo "<p><strong>Response:</strong> " . $row_review['response'] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No reviews found for $maid_name.</p>";
            }
        } else {
            echo "<p>No candidate selected.</p>";
        }

        mysqli_close($conn);
        ?>
        <div class="back-link">
            <a href="javascript:history.go(-1)">Go Back</a>
        </div>
    </div>
</body>
</html>
