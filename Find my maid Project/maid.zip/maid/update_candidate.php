<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();


if (!isset($_SESSION['candidate_id'])) {
    header("Location: login.php");
    exit();
}

$candidate_id = $_SESSION['candidate_id'];

$sql = "SELECT * FROM user_form WHERE id = '$candidate_id' AND user_type = 'candidate'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $candidate_profile = mysqli_fetch_assoc($result);
} else {
 
    echo "Error fetching candidate data.";
    exit();
}


if (isset($_POST['update'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    $image = $_FILES['image']['name'];
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = 'uploaded_img/'.$image;


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } else {
        $update_query = "UPDATE user_form SET email = '$email' WHERE id = '$candidate_id' AND user_type = 'candidate'";
        mysqli_query($conn, $update_query);
    }

    if (!preg_match("/^[0-9]{10}$/", $phone_number)) {
        $error = "Invalid phone number format. Please enter 10 digits.";
    } else {
        $update_query = "UPDATE user_form SET phone_number = '$phone_number' WHERE id = '$candidate_id' AND user_type = 'candidate'";
        mysqli_query($conn, $update_query);
    }

  
    if (!empty($new_password) && !empty($confirm_password)) {
        if ($new_password === $confirm_password) {
            $update_query = "UPDATE user_form SET password = '$new_password' WHERE id = '$candidate_id' AND user_type = 'candidate'";
            mysqli_query($conn, $update_query);
        } else {
            $error = "Passwords do not match.";
        }
    }


    if (!empty($image)) {
        if ($image_size > 2000000) {
            $error = 'Image size is too large!';
        } else {
            move_uploaded_file($image_tmp_name, $image_folder);
            $update_query = "UPDATE user_form SET image = '$image' WHERE id = '$candidate_id' AND user_type = 'candidate'";
            mysqli_query($conn, $update_query);
        }
    }


    header("Location: candidate_page.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 5px;
        }
        .form-group .btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group .btn:hover {
            background-color: #0056b3;
        }
        .error-msg {
            color: red;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Your Profile</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $candidate_profile['email']; ?>" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="text" id="phone" name="phone_number" value="<?php echo $candidate_profile['phone_number']; ?>" required>
            </div>
            <div class="form-group">
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" placeholder="Leave blank to keep current password">
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Leave blank to keep current password">
            </div>
            <div class="form-group">
                <label for="image">Profile Picture:</label>
                <input type="file" id="image" name="image" class="box" accept="image/jpg, image/jpeg, image/png">
            </div>
            <?php if(isset($error)): ?>
                <div class="error-msg"><?php echo $error; ?></div>
            <?php endif; ?>
            <div class="form-group">
                <input type="submit" name="update" value="Update Profile" class="btn">
            </div>
        </form>
    </div>
</body>
</html>
