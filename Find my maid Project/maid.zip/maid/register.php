<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


session_start();


$error = [];
$message = [];

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $jobs = mysqli_real_escape_string($conn, $_POST['jobs']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $pass = ($_POST['password']);
    $cpass = ($_POST['cpassword']);
    $user_type = $_POST['user_type'];
    $image = $_FILES['image']['name'];
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = 'uploaded_img/'.$image;

    $select = "SELECT * FROM user_form WHERE email = '$email'";
    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {
        $error[] = 'User already exists!';
    } else {
        if ($pass != $cpass) {
            $error[] = 'Confirm password not matched!';
        } elseif ($image_size > 2000000) {
            $error[] = 'Image size is too large!';
        } else {
            $insert = mysqli_query($conn, "INSERT INTO `user_form`(name, email, phone_number, jobs, address, password, user_type, image) VALUES('$name', '$email', '$phone_number', '$jobs', '$address', '$pass', '$user_type', '$image')") or die('Query failed');

            if ($insert) {
                move_uploaded_file($image_tmp_name, $image_folder);
                $message[] = 'Registered successfully!';
            } else {
                $error[] = 'Registration failed!';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .form-container {
         max-width: 600px; /* Increase the max-width value */
         margin: 20px auto;
         padding: 20px;
         background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }


        h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-btn {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            font-size: 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-btn:hover {
            background-color: #0056b3;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .error-msg {
            color: red;
            margin-top: 10px;
        }
        .success-msg {
            color: green;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="form-container">
 
        <form action="" method="post" enctype="multipart/form-data">
            <h3>Register Now</h3>
            <?php if(!empty($error)): ?>
                <?php foreach($error as $error_msg): ?>
                    <span class="error-msg"><?php echo $error_msg; ?></span>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php if(!empty($message)): ?>
                <?php foreach($message as $msg): ?>
                    <span class="success-msg"><?php echo $msg; ?></span>
                <?php endforeach; ?>
            <?php endif; ?>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" placeholder="Enter your name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="text" name="phone_number" id="phone" placeholder="Enter your phone number" required>
            </div>
            <div class="form-group">
                <label for="jobs">Preferred Jobs:</label>
                <input type="text" name="jobs" id="jobs" placeholder="Enter preferred jobs" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" name="address" id="address" placeholder="Enter your address" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" placeholder="Enter your password" required>
            </div>
            <div class="form-group">
                <label for="cpassword">Confirm Password:</label>
                <input type="password" name="cpassword" id="cpassword" placeholder="Confirm your password" required>
            </div>
            <div class="form-group">
                <label for="user_type">User Type:</label>
                <select name="user_type" id="user_type" required>
                    <option value="user">User</option>
                    <option value="candidate">Candidate</option>
                </select>
            </div>
            <div class="form-group">
                <label for="image">Profile Image:</label>
                <input type="file" name="image" id="image" class="box" accept="image/jpg, image/jpeg, image/png">
            </div>
            <input type="submit" name="submit" value="Register Now" class="form-btn">
            <p>Already have an account? <a href="login.php">Login Now</a></p>
        </form>
    </div>
</body>
</html>
