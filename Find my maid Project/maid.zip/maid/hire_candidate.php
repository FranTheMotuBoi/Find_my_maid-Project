<?php
session_start();


if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$user_name = $_SESSION['user_name'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['hire_candidate'])) {

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "findmymaid";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }


    $candidate_name = $_POST['candidate_name'];
    $preferred_location = $_POST['preferred_location'];
    $preferred_jobs = $_POST['preferred_jobs'];
    $previous_job_location = $_POST['previous_job_location'];
    $experience = $_POST['experience'];
    $expected_salary = $_POST['expected_salary'];

    
    $sql_insert = "INSERT INTO hired_maids (name, maid_name, preferred_location, preferred_jobs, previous_job_location, experience, expected_salary) 
                    VALUES ('$user_name', '$candidate_name', '$preferred_location', '$preferred_jobs', '$previous_job_location', '$experience', '$expected_salary')";

    if (mysqli_query($conn, $sql_insert)) {

        header("Location: user_page.php");
        exit();
    } else {
        echo "Error hiring candidate: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
?>
