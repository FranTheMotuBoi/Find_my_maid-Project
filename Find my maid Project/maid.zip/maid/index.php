<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
    body {
        font-family: Arial, sans-serif; 
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
    }
    .navbar {
        background-color: #007bff;
        overflow: hidden;
    }
    .navbar a {
        float: right;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }
    .navbar a:hover {
        background-color: #0056b3;
    }
    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    }
    h1 {
        text-align: center;
        font-size: 28px;
        margin-bottom: 20px;
    }
    .logo {
        text-align: center; /* Align center instead of left */
        margin-bottom: 20px;
    }
    .logo span {
        font-weight: bold;
        font-size: 32px;
        color: crimson;
        font-style: italic;
    }
    .job-list {
        margin-top: 20px;
    }
    .job {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 10px;
    }
    .job h3 {
        margin-top: 0;
    }
    .job p {
        margin: 5px 0;
    }
    .view-review-button {
        padding: 8px 16px; /* Adjust button padding */
        background-color: crimson;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-review-button:hover {
        background-color: darkred;
    }

    </style>
</head>
<body>

    <div class="navbar">
        <div class="menu">
            <a href="login.php">Log In</a>
            <a href="register.php">Register</a>
        </div>
    </div>

   
    <div class="container">
        <div class="logo">
            <span>FindMyMaid</span>
        </div>
        <h1>Welcome to FindMyMaid!</h1>
        
        <div class="job-list">
            <h2>Posted Jobs by Candidates:</h2>
            <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "findmymaid";

            $conn = mysqli_connect($servername, $username, $password, $dbname);

         
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $sql = "SELECT * FROM post_maid";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="job">
                        <h3><?php echo $row['candidate_name']; ?></h3>
                        <p><strong>Preferred Location:</strong> <?php echo $row['preferred_location']; ?></p>
                        <p><strong>Preferred Jobs:</strong> <?php echo $row['preferred_jobs']; ?></p>
                        <p><strong>Experience:</strong> <?php echo $row['experience']; ?></p>
                        <p><strong>Previous Job Location:</strong> <?php echo $row['previous_job_location']; ?></p>
                        <p><strong>Expected Salary:</strong> <?php echo $row['expected_salary']; ?></p>
                        <form action="view_review.php" method="post">
                            <input type="hidden" name="candidate_name" value="<?php echo $row['candidate_name']; ?>">
                            <button type="submit" name="view_review" class="view-review-button">View Review</button>
                        </form>
                    </div>
                    <?php
                }
            } else {
                echo "<p>No jobs posted yet.</p>";
            }

            mysqli_close($conn);
            ?>
        </div>
    </div>
</body>
</html>
