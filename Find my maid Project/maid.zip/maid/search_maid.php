<?php



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if(isset($_GET['search'])) {
    
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    
    
    $sql = "SELECT * FROM post_maid WHERE preferred_location LIKE '%$search%' OR expected_salary LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);

    
    if(mysqli_num_rows($result) > 0) {
        
        echo "<h2>Candidates Found:</h2>";
        while($row = mysqli_fetch_assoc($result)) {
            echo "<div class='job-listing'>";
            echo "<p><strong>Candidate Name:</strong> " . $row['candidate_name'] . "</p>";
            echo "<p><strong>Preferred Location:</strong> " . $row['preferred_location'] . "</p>";
            echo "<p><strong>Preferred Jobs:</strong> " . $row['preferred_jobs'] . "</p>";
            echo "<p><strong>Previous Job Location:</strong> " . $row['previous_job_location'] . "</p>";
            echo "<p><strong>Experience:</strong> " . $row['experience'] . "</p>";
            echo "<p><strong>Expected Salary:</strong> " . $row['expected_salary'] . "</p>";
            echo "</div>";
        }
    } else {
        
        echo "No candidates found based on the search criteria.";
    }
} else {
    
    header("Location: user_page.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Maid</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Style for job listings */
        .job-listing {
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .job-listing p {
            margin: 5px 0;
        }

        .job-listing h2 {
            margin-top: 0;
            color: #007bff;
        }
    </style>
</head>
<body>
    
</body>
</html>
