<?php
// Start session
session_start();

// Check if user is not logged in
if (!isset($_SESSION['admin_name'])) {
    header("Location: login.php");
    exit();
}

// Logout handling
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "findmymaid";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user data
$sql_users = "SELECT * FROM user_form WHERE user_type = 'user'";
$result_users = mysqli_query($conn, $sql_users);

// Fetch candidate data
$sql_candidates = "SELECT * FROM user_form WHERE user_type = 'candidate'";
$result_candidates = mysqli_query($conn, $sql_candidates);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #333;
            overflow: hidden;
            padding: 10px 0;
        }
        .navbar a {
            float: right;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        h1 {
            text-align: center;
        }
        .user-list, .candidate-list {
            margin-top: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        li {
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="#" class="active">Home</a>
        <form action="" method="post">
            <input type="submit" name="logout" value="Logout" style="background-color: red;">
        </form>
    </div>
    <div class="container">
        <h1>Welcome, <?php echo $_SESSION['admin_name']; ?>!</h1>
        <div class="user-list">
            <h2>Users</h2>
            <ul>
                <?php while ($row_users = mysqli_fetch_assoc($result_users)) : ?>
                    <li><?php echo $row_users['name']; ?></li>
                <?php endwhile; ?>
            </ul>
        </div>
        <div class="candidate-list">
            <h2>Candidates</h2>
            <ul>
                <?php while ($row_candidates = mysqli_fetch_assoc($result_candidates)) : ?>
                    <li><?php echo $row_candidates['name']; ?></li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>
</body>
</html>
